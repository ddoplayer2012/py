#-*- coding:utf-8 -*-


class lesson(object):
    '''
    课程类
    member:名字，价格，周期
    '''

    def __init__(self,lesson_name,lesson_price,lesson_period):
        self.lesson_name = lesson_name
        self.lesson_price = lesson_price
        self.lesson_period = lesson_period


