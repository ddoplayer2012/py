#-*- coding:utf-8 -*-

import re
import functools


def split_bracket1(number):
    '''
    分离出括号，接下来再详细处理
    :return:
    '''
    #循环分离括号的标志位
    calc_flag = True
    while calc_flag:

        bracket_nember = re.search('\([^()]*\)',number)
        if bracket_nember:
            #计算值
            sub_result = calculate2(bracket_nember.group())
            #替换计算结果，进入下个循环查找括号
            number = number.replace(bracket_nember.group(),str(sub_result))
        else:
            print("括号分离完毕，准备下一阶段")
            print("最终结果为：%f"%calculate2(number))
            calc_flag = False

def remove_duplicates(formula):
    formula = formula.replace("++","+")
    formula = formula.replace("+-","-")
    formula = formula.replace("-+","-")
    formula = formula.replace("--","+")
    formula = formula.replace("- -","+")
    return formula

def calculate2(number):
    number = number.strip("()")
    number = number.strip()
    number = number.replace(" ","")
    number = remove_duplicates(number)
    plus_and_minus_operators = re.findall("[+-]", number)
    #['-', '-', '-', '-', '+', '+']
    multiply_and_dividend = re.split("[+-]", number)  # 取出乘除公式
    #['', '9', '2', '5', '2*5/3', '7/3*99/4*2998', '10*568/14']  空格strip长度为0代表是负号
    if (len(multiply_and_dividend[0].strip())) == 0:
        multiply_and_dividend[1] =  plus_and_minus_operators[0] + multiply_and_dividend[1]
        del multiply_and_dividend[0]
        del plus_and_minus_operators[0]
    #处理部分代码分割引起的字符串顺序混乱造成结果异常
    plus_and_minus_operators, multiply_and_dividend = string_exception3(plus_and_minus_operators, multiply_and_dividend)
    #print(multiply_and_dividend)
    #处理*/
    for index,value in enumerate(multiply_and_dividend):
        if re.search("[*/]",value):
            multiply_and_dividend[index] = calc_multi_and_divi(value)
    #处理+-['-9', '2', '5', 3.3333333333333335, 173134.50000000003, 405.7142857142857]
    print(multiply_and_dividend,plus_and_minus_operators)
    sub_res = None
    for index, j in enumerate(multiply_and_dividend):
        if sub_res:
            if plus_and_minus_operators[index - 1] == '+':
                sub_res += float(j)
            elif plus_and_minus_operators[index - 1] == '-':
                sub_res -= float(j)
        else:
            sub_res = float(j)
    print("[%s]计算结果为：%f"%(number,sub_res))
    return sub_res


def calc_multi_and_divi(value):
    '''
    先分割，再计算，返回计算结果的值
    :param value:
    :return: 计算value的结果
    '''
    operators = re.findall("[*/]",value)
    key = re.split("[*/]",value)
    sub_res = None
    for index,j in enumerate(key):
        if sub_res:
            if operators[index - 1] == '*':
                sub_res *= float(j)
            elif operators[index - 1] == '/':
                sub_res /= float(j)
        else:
            sub_res = float(j)
    print("\033[31;1m[%s]运算结果=\033[0m" % value, sub_res)
    return sub_res

def string_exception3(plus_and_minus_operators, multiply_and_dividend):
    '''有时会出现这种情况 , ['-', '-'] ['1 ', ' 2 * ', '14969036.7968254'],2*...后面这段实际是 2*-14969036.7968254,需要特别处理下,负号优先级高于*/'''
    #enumerate的作用是替代for i in range(len(xxx)):
    for index, i in enumerate(multiply_and_dividend):
        i = i.strip()
        if i.endswith("*") or i.endswith("/"):
            #   直接先合成一个列表的值 2* || - || 14969
            multiply_and_dividend[index] = multiply_and_dividend[index] + plus_and_minus_operators[index] + \
                                           multiply_and_dividend[index + 1]
            del multiply_and_dividend[index + 1]
            del plus_and_minus_operators[index]
    return plus_and_minus_operators, multiply_and_dividend

if __name__ == '__main__':
    # res = calc("1 - 2 * ( (60-30 +(-40/5) * (9-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 )) - (-4*3)/ (16-3*2) )")
 #   res = calc(
  #      "1 - 2 * ( (60-30 +(-9-2-5-2*3-5/3-40*4/2-3/5+6*3) * (-9-2-5-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 )) - (-4*3)/ (16-3*2) )")
   # res = split_bracket1(
  #   " 1 + (-9-2-5-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 ) - (-4*3)/ (16-3*2)")
    number = "1 - 2 * ( (60-30 +(-9-2-5-2*3-5/3-40*4/2-3/5+6*3) * (-9-2-5-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 )) - (-4*3)/ (16-3*2) )"
    res = split_bracket1(number)